
//GETTING THE COORDINATES
public class Position {
    int row;
    int col;

    public Position(int row, int col){
        this.col = col;
        this.row = row;
    }
}